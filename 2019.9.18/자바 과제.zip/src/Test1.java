public class Test1 {
	public static void main(String args[]) {
		System.out.print("Hello World");
		System.out.println("Hello World");
		System.out.printf("Hello World");
		System.out.format("Hello World");
	}
}
